-- CSci 117, Lab 3:  ADTs and Type Classes
import Data.List (sort)
import Queue1
--import Queue2
import Fraction

---------------- Part 1: Queue client

-- Queue operations (A = add, R = remove)
data Qops a = A a | R

-- Perform a list of queue operations on an emtpy queue,
-- returning the list of the removed elements
perf :: [Qops a] -> [a]
perf ops = help ops mtq where
    help [] c = []
    help (A x:ops) c = help ops (addq x c)
    help (R:ops) c = let (x,c2) = remq c
	                in x: help ops c2

-- Test the above functions thouroughly. For example, here is one test:
-- perf [A 3, A 5, R, A 7, R, A 9, A 11, R, R, R] ---> [3,5,7,9,11]
-- perf [A 3, A 5, R]



---------------- Part 2: Using typeclass instances for fractions

-- Construct a fraction, producing an error if it fails
fraction :: Integer -> Integer -> Fraction
fraction a b = case frac a b of
             Nothing -> error "Not a valid Fraction"
             Just f -> f


-- Calculate the average of a list of fractions
-- Give the error "Empty average" if xs is empty
average :: [Fraction] -> Fraction
average xs = go xs where
	go [] = error "Empty average"
	go xs = sum xs * fraction 1 (fromIntegral(length xs))

-- Some lists of fractions

list1 = [fraction n (n+1) | n <- [1..20]]
list2 = [fraction 1 n | n <- [1..20]]



-- Make up several more lists for testing
list4 = [fraction (maximum [3,2,5,6,2]) (minimum [2,7,9,2,5])]
list5 = [fraction (product [5,2,3,6]) (sum [2,7,2,6])]

-- Show examples testing the functions sort, sum, product, maximum, minimum,
-- and average on a few lists of fractions each. Think about how these library
-- functions can operate on Fractions, even though they were written long ago
