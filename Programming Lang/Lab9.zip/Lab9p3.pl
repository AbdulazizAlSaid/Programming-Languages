knightTour(N,M,T) :- N2 is (N*M) - 1,
  kT(N,M,N2,[m(0,0)],T). 

kT(_,_,0,T,T).
kT(N,M,N2,[m(P1,P2)|Pt],T) :-
    moves(m(P1,P2), m(D1,D2)),       
    D1>=0, D2>=0, D1<N, D2<M,        
    + member(m(D1,D2),Pt),           
    N3 is N2-1,
    kT(N,M,N3,[m(D1,D2),m(P1,P2)|Pt],T).

closedKnightsTour(N,M,T) :-    N2 is (N*M)-1,
   kT(N,M,N2,[m(0,0)],T), closed(T,0,0). 

moving(m(X,Y), m(U,V)) :-
  member(m(A,B), [m(1,2),m(1,-2),m(-1,2),m(-1,-2),m(2,1),m(2,-1),m(-2,1),m(-2,-1)]),
  U is X + A,
  V is Y + B.

closed([m(P1,P2)|_],O1,O2) :- moves(m(P1,P2),m(O1,O2)).