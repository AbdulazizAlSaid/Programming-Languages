determiner(N, P1, P2, [every|X], X, all(N, imply(P1,P2))).
determiner(N, P1, P2, [a|X], X, exists(N, and(P1,P2))). %%%%%

    
%first case is for all 
%second case is there exists

    
noun(N, [man|X], X, man(N)).
noun(N, [woman|X], X, woman(N)).
noun(N, [child|X], X, child(N)).

name([john|X], X, john()).
name([mary|X], X, mary()).
name([tom|X], X, tom()).
name([jerry|X], X, jerry()).

    
transverb(S, O, [loves|X], X, loves(S, O)).
transverb(S, O, [hates|X], X, hates(S, O)).

intransverb(S, [lives|X], X, lives(S)).
intransverb(S, [hides|X], X, hides(S)).

%checks if head is lives
    
sentence(X0, X, Out):- 
    nounphrase(N, P1, X0, X1, Out),
    verbphrase(N, X1, X, P1).


%Call nounphrase and verbphrase
    
nounphrase(N, P1, X0, X, Out):- 
    determiner(N, P2, P1, X0, X1, Out),
    noun(N, X1, X2, P3),
    relclause(N, P3, X2, X, P2).
nounphrase(N, P1, X0, X, P1):-
	name(X0, X, N).   
    
%calls determiner, noun, and relclause
%Calls name
    
verbphrase(S, X0, X, Out):-
    transverb(S, O, X0, X1, P1),  
	nounphrase(O, P1, X1, X, Out).
verbphrase(S, X0, X, Out):-
    intransverb(S, X0, X, Out).

%call transverb and nounphrase
%call intransverb
relclause(S, P1, [who|X1], X, and(P1,P2)):-%%%%
    name(X1, Xs, Out101),
    transverb(Out101, S, Xs, X, P2).   
relclause(S, P1, [who|X1], X, and(P1,P2)):-%%%
    verbphrase(S, X1, X, P2).

%relclause(S, P1, X, X, P1).